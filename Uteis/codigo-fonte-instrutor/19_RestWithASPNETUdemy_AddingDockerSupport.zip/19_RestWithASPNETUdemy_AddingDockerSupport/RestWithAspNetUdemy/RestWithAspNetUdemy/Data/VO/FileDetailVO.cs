﻿namespace RestWithAspNetUdemy.Data.VO
{
    public class FileDetailVO
    {
        public string DocName { get; set; }

        public string DocType { get; set; }
        
        public string DocUrl { get; set; }
    }
}
