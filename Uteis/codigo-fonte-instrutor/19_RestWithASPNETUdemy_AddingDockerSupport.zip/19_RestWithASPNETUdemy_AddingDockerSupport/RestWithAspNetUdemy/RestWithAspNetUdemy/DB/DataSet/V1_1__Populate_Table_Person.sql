INSERT INTO `person` (`id`, `address`, `first_name`, `gender`, `last_name`) VALUES
(1, 'Sao Paulo - Brasil', 'Ayrton', 'Male', 'Senna'),
(2, 'Anchiano - Italy', 'Leonardo', 'Male', 'da Vinci'),
(3, 'Porbandar - India', 'Mahatma', 'Male', 'Gandhi'),
(4, 'Kentucky - USA', 'Mohamed Ali', 'Male', 'Gandhi'),
(5, 'Mvezo - South Africa', 'Nelson', 'Male', 'Mandela');